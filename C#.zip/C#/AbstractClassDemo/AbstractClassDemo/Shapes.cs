﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    public abstract class Shapes
    {
        public abstract void Draw();
        public void Show()
        {
            Console.WriteLine("Show method of Shape class");
        }

    }
}
