﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] array1=new int[5]; // (array with default value)
            //int[] array2 = new int[] { 1, 2, 3, 4, 5 };  (declares and sets array element)
            //int[] array3 = { 3, 5, 8, 2, 1 };
            //Console.WriteLine("Value of array {0}",array1[i]);
            //Console.WriteLine("Value of array {0}", array2[i]);
            // Console.WriteLine("Value of array {0}", array3[i]);

            int[] IntArray=new int[5];
            Console.WriteLine("Enter the elements of array: ");
            for (int i = 0; i < IntArray.Length; i++)
            {
                IntArray[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Array Elements Are: ");
            for (int i = 0; i < IntArray.Length; i++)
            {
                Console.Write(IntArray[i] + "\t"); 
            }
            Console.WriteLine();
            Console.WriteLine("The sorted array are: ");
            Array.Sort(IntArray);
            for (int i = 0; i < IntArray.Length; i++)
            {
                Console.Write(IntArray[i] + "\t");
            }
            Console.WriteLine();
            Console.WriteLine("The reverse of the array are: ");
            Array.Reverse(IntArray);
            for (int i = 0; i < IntArray.Length; i++)
            {
                Console.Write(IntArray[i] + "\t");
            }
            Console.ReadKey();
        }
    }
}
