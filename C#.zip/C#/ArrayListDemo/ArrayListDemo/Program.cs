﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrList = new ArrayList();
            arrList.Add(10);
            arrList.Add(".NET");
            arrList.Add(true);
            arrList.Add(DateTime.Now);
            arrList.Add('s');
                   
            Console.WriteLine("Number of Elements: " + arrList.Count);
            Console.WriteLine("Capacity of Arraylist: " + arrList.Capacity);
            Console.WriteLine("Array List Element : ");

            foreach (var value in arrList)
            {
                Console.WriteLine(value);
            }

            object[] arr = new object[20];
            //arrList.CopyTo(Array array)
            //arrList.CopyTo(arr);

            //arrList.CopyTo(Array array,indexNumber)
            //arrList.CopyTo(arr, 3);

            //CopyTo(listindex,array,arrayindex,count)
            arrList.CopyTo(2, arr, 4, 3);
            Console.WriteLine("\nArray elements which are copied from the collection");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i] + "\t");
            }


            Console.ReadKey();

        }
    }
}
