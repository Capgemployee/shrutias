﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace EmployeeDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Employee[] emp = new Employee[2];
            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter Employee Id: ");
                emp[i].setEmpId(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Enter Employee Name: ");
                emp[i].setEmpName(Console.ReadLine());
                Console.WriteLine("Enter Employee Address: ");
                emp[i].setEmpAddress(Console.ReadLine());
                Console.WriteLine("Enter Employee Department: ");
                emp[i].setEmpDept(Console.ReadLine());
                Console.WriteLine("Enter City: ");
                emp[i].setCity(Console.ReadLine());
                Console.WriteLine("Enter Employee Salary: ");
                emp[i].setEmpSalary(Convert.ToDouble(Console.ReadLine()));
            }
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("\n\nEmployee Name is : " + emp[i].getName());
                Console.WriteLine("\n\nEmployee Salary is : " + emp[i].getSalary()); 
            }
            
            Console.ReadKey();
        }
    }
   
}
