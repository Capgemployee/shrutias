﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathsLibrary;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1;
            double number2;
            char choice;
            double sum, diff, prod, quotient, remainder;

            ArithmeticOperations cal = new ArithmeticOperations();

            Console.Write("Enter Number 1: ");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number 2: ");
            number2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter Choice: ");
            Console.WriteLine("A: Addition");
            Console.WriteLine("B: Subtraction");
            Console.WriteLine("C: Multiplication");
            Console.WriteLine("D: Division");
            Console.WriteLine("E: Modulus");
            choice = Convert.ToChar(Console.ReadLine());
            switch (choice)
            {
                case 'A':
                    sum = cal.Add(number1, number2);
                    Console.WriteLine("The result of Addition is : {0}", sum);
                    break;

                case 'B':
                    diff = cal.Sub(number1, number2);
                    Console.WriteLine("The result of Subtraction is : {0}", diff);
                    break;

                case 'C':
                    prod = cal.Mul(number1, number2);
                    Console.WriteLine("The result of Multiplication is : {0}", prod);
                    break;

                case 'D':
                    quotient = cal.Div(number1, number2);
                    Console.WriteLine("The result of Division is : {0}", quotient);
                    break;

                case 'E':
                    remainder = cal.Mod(number1, number2);
                    Console.WriteLine("The result of Modulus is : {0}", remainder);
                    break;

            }
            Console.ReadKey();

        }
    }
}
