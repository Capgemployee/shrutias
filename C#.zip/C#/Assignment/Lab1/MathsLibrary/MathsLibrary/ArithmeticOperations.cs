﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathsLibrary
{
    public class ArithmeticOperations
    {
        public double Add(int num1, double num2)
        {
            return (num1 + num2);
        }

        public double Sub(int num1, double num2)
        {
            return (num1 - num2);
        }

        public double Mul(int num1, double num2)
        {
            return (num1 * num2);
        }

        public double Div(int num1, double num2)
        {
            return (num1 / num2);
        }

        public double Mod(int num1, double num2)
        {
            return (num1 % num2);
        }
    }
}
