﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecord
{
    class Student
    {
        private int rollNumber;
        private string studentname;
        private byte age;
        private char gender;
        private DateTime dateOfBirth;
        private string address;
        private float percentage;

        public int RollNumber
        {
            get { return rollNumber; }
            set { rollNumber = value; }
        }

        public string StudenName
        {
            get { return studentname; }
            set { studentname = value; }
        }
        public byte Age
        {
            get { return age; }
            set { age = value; }
        }
        public char Gender
        {
            get { return gender; }
            set { gender = value; }
        }
        public DateTime DOB
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public float Percentage
        {
            get { return percentage; }
            set { percentage = value; }
        }
     
       
    }
}
