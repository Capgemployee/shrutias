﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            char option;
            
            Console.WriteLine("Main Menu");
            Console.WriteLine("1. Option1");
            Console.WriteLine("2. Option2");
            Console.WriteLine("3. Option3");
            Console.WriteLine("4. Option4");
            Console.WriteLine("5. Option5");
            Console.Write("Enter the Option : ");
            option = Convert.ToChar(Console.ReadLine());
            switch (option)
            {
                case '1':
                   
                    Console.WriteLine("You have choosed Option1");
                    break;
                case '2':
                    
                    Console.WriteLine("You have choosed Option2");
                    break;
                case '3':
                    
                    Console.WriteLine("You have choosed Option3");
                    break;
                case '4':
                    
                    Console.WriteLine("You have choosed Option4");
                    break;
                case '5':

                    Console.WriteLine("You have choosed Option5");
                    break;
                default:
                    Console.WriteLine("Invalid Option");
                    break;
            }
            Console.ReadLine();

        }
    }
}
