﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDetails
{
    class BooksDemo
    {
        static void Main(string[] args)
        {
            string[] colName=new string[4];
            Console.WriteLine("The Colunm names are: ");
            for (int i = 0; i < colName.Length; i++)
            {
                colName[i] = Console.ReadLine();
            }

            string[,] bookDetails = new string[2, 4];
            Console.WriteLine("Enter the book details: ");
            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    bookDetails[i, j] = (Console.ReadLine());
                }
            }

            Console.WriteLine("The book details are: ");

            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {

                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    Console.WriteLine(bookDetails[i, j]);

                }
                Console.WriteLine();
            }

            Console.ReadKey();

        }
    }
}
