﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDimArray
{
    class Program
    {
        static void Main(string[] args)
        {

            int[,] matrix = new int[5, 6];

            Console.WriteLine("Enter the elements of matrix: ");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("The array elements are: ");

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
             
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                   Console.WriteLine( matrix[i, j]) ;
                   
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
