﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimArray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] city =new string[5];

            Console.WriteLine("Enter the name of city: ");
            for (int i = 0; i < city.Length; i++)
            {
                city[i]=Console.ReadLine();
            }
            Console.WriteLine("The array elements are: ");

            foreach(string name in city)
            {
            Console.Write(name+"\t");
            }

            Console.ReadKey();

        }
    }
}
