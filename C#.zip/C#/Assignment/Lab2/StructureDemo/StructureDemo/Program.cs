﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    public class Program
    {
        public struct Operation
        {
            public int number;

            public int Square()
            {
                return number * number;
            }

            public int Cube()
            {
                return number * number * number;
            }
        };
        static void Main(string[] args)
        {
            Operation obj = new Operation();
            obj.number = 2;
            int sqrt = obj.Square();
            Console.WriteLine("Square of number= "+sqrt);
            int cube = obj.Cube();
            Console.WriteLine("Cube of number= "+cube);
            
            Console.ReadKey();
        }
    }
}
