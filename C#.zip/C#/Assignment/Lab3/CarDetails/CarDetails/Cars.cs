﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDetails
{
    class Cars
    {
        string make;
        int model;
        int year;
        int salePrice;

        public Cars()
        {
        }
        public Cars(int carModel)
        {
            this.model = carModel;
        }

        public string CarMake
        {
            get { return make; }
            set { make = value; }
        }

        public int Model
        {
            get { return model; }
            set { model = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public int SalePrice
        {
            get { return salePrice; }
            set { salePrice = value; }
        }

        object[] car = new object[10];

        Cars c = new Cars();
        public void Add()
        {
            Console.WriteLine("Enter Car Name");
            c.CarMake = Console.ReadLine();
            Console.WriteLine("Enter Car Model");


        }

    }
}
