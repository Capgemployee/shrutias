﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectLibrary;

namespace ParticipantDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalmarks=300;
            Participant p = new Participant();

            Console.WriteLine("Enter Employee ID");
            p.EmployeeID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            p.  =(Console.ReadLine());
            Console.WriteLine("Enter Foundation Marks");
            p.FoundationMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Web Basic Marks");
            p.WebBasicMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Dot Net Marks");
            p.DotNetMarks = Convert.ToInt32(Console.ReadLine());

            int obtainedMarks = p.ObtainedMarks(p.FoundationMarks, p.DotNetMarks, p.WebBasicMarks);
            Console.WriteLine("Obtained Marks : "+obtainedMarks);

            double percentage = p.Percentage(totalmarks, obtainedMarks);
           
            p.DisplayPercentage(percentage);
       
            Console.ReadKey();
        }
    }
}
