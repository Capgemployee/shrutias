﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTestDemo
{
    class Supplier
    {
         private int supplierID;
         private string supplierName;
         private string city;
         private string phoneNo;
         private string email;

        public void AcceptDetails()
        {
                Console.WriteLine("Enter the Supplier ID");
                supplierID=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Supplier Name");
                supplierName = (Console.ReadLine());
                Console.WriteLine("Enter the city");
                city = (Console.ReadLine());
                Console.WriteLine("Enter the Phone No");
                phoneNo = (Console.ReadLine());
                Console.WriteLine("Enter the Email Id");
                email = (Console.ReadLine());

        }
  
        public void DisplayDetails()
        {
            Console.WriteLine("The Supplier ID is :" + supplierID);
            Console.WriteLine("The Supplier ID is :" + supplierName);
            Console.WriteLine("The Supplier ID is :" + city);
            Console.WriteLine("The Supplier ID is :" + phoneNo);
            Console.WriteLine("The Supplier ID is :" + email);

        }

    }
}
