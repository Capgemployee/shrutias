﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssymetricAccessorProperty
{
    public class Employee
    {
        int empID;
        public int EmployeeID
        {
            get { return empID; }
            private set { empID = value; }
        }
        string name;
        public string EmployeeName
        {
            get { return name; }
            set { name = value; }
        }

        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmployeeID = 101;
            emp.EmployeeName = "Shruti";

            Console.WriteLine("Employee ID: " + emp.EmployeeID);
            Console.WriteLine("Employee Name: " + emp.EmployeeName);
            Console.ReadKey();
        }
    }
}
