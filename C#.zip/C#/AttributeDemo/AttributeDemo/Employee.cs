﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeDemo
{
    [Author("Shruti","jamgade")]
    public class Employee
    {
        public int MyProperty { get; set; }

    }
}
