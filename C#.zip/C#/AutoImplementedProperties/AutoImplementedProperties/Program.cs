﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedProperties
{
    public class Program
    {
        static void Main(string[] args)
        {
           Employee emp = new Employee();

           Console.WriteLine("Enter EmployeeID");
           emp.EmployeeID = Convert.ToInt32(Console.ReadLine());





           Console.WriteLine("EmployeeID; " + emp.EmployeeID);


            
        }
    }
}
