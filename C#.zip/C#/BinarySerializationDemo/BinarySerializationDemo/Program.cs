﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BinarySerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { EmployeeID = 101, EmployeeName = "Shruti" ,Salary=2000};
            FileStream fs = new FileStream("binSer.txt", FileMode.Create, FileAccess.Write);

            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, emp);

            fs.Close();

            fs = new FileStream("binSer.txt", FileMode.Open, FileAccess.Read);

            Employee anotherEmp = (Employee)bin.Deserialize(fs);
            fs.Close();
            Console.WriteLine("Employee ID : " + anotherEmp.EmployeeID);
            Console.WriteLine("Employee Name : " + anotherEmp.EmployeeName);
            Console.WriteLine("Employee Salary : " + anotherEmp.Salary);

            Console.ReadKey();
        }
    }
}
