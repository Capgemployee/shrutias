﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstraintDemo
{
    public class Myclass<T> where T:struct   //class fr reference type and struct for value type
    {
    }
    public class Customer { }

    public struct DOB { }

    class Program
    {
        static void Main(string[] args)
        {
            Myclass<int> intObj = new Myclass<int>();
            Myclass<DOB> dobObj = new Myclass<DOB>();
            Myclass<Customer> custObj = new Myclass<Customer>(); 
                                            //error coz we have applied constraint of value type


        }
    }
}
