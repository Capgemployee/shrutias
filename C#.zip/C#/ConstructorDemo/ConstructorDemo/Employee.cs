﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo
{
    public  class Employee
    {
        public Employee()
        {
            Console.WriteLine("Default Constructor is called..");
        }
        public Employee(string name)
        {
            Console.WriteLine("Parameterized Constructor is called.."+name);
        }
        static Employee()
        {
            Console.WriteLine("Static Constructor is called..");
        }


        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Employee emp1 =new Employee("shruti");
       
            Console.ReadKey();
        }
        
    }
}
