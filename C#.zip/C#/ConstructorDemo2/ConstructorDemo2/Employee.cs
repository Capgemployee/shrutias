﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo2
{
    public class Employee
    {
        int empId;
        string empName;
        double sal;

        public Employee()
        {
            empId = 101;
            empName = "shruti";
            sal = 12000.330;
        }

        public Employee(int empId,string empName,double sal)
        {
            this.empId = empId;
            this.empName = empName;
            this.sal = sal;
        }
        public void Print()
        {
            Console.WriteLine("Employee Id is :" + empId);
            Console.WriteLine("Employee Name is :" + empName);
            Console.WriteLine("Employee Salary is :" + sal);
        }

        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Employee emp1 = new Employee(102, "shru", 200000);
            emp.Print();
            emp1.Print();
            Console.ReadKey();
        }
    }
}
