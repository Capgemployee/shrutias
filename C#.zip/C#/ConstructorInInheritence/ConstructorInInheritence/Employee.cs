﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInInheritence
{
    public class Employee
    {
        public Employee()
        {
            Console.WriteLine("This is default constructor");
        }
        public Employee(string name)
        {
            Console.WriteLine("This is parameterized constructor");
        }
    }
}
