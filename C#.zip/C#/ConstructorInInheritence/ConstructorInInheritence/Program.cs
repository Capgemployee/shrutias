﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInInheritence
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m = new Manager();

            Manager mgr = new Manager("Shruti");
            
            Console.ReadKey();
        }
    }
}
