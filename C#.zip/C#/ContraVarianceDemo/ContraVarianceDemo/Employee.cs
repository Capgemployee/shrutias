﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContraVarianceDemo
{
    class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public int DepartID { get; set; }

        public Employee(int empID, string name, int departID)
        {
            EmpID = empID;
            EmpName = name;
            DepartID = departID;
        }
    }
}
