﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContraVarianceDemo
{
    class Manager:Employee
    {
        public int Allowance { get; set; }
        public Manager(int id, string name, int dept, int all)
            : base(id, name, dept)
        {
            Allowance = all;
        }

    }
}
