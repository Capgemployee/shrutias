﻿using System;
using System.Collections.Generic;//Collection is the namespace within namespace System
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 10;
            //Boxing: Converting value type to reference type
            object o = num;
            //Unboxing: Converting reference to value type
            int number = (Int32)o;

            //Nullable types: Allows null value to value type
            //Nullable<int> val = null;
            int? val = null;

            if (val.HasValue)
            {
                Console.WriteLine("Value is: "+val.Value);
            }
            else
            {
                Console.WriteLine("Value is null");
            }
            //this is written to get the output window with f5
            Console.Write("Press any key to continue....");
            Console.ReadKey();
        }
    }
}
