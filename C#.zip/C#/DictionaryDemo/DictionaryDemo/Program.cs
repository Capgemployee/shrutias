﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Program
    {
        public class Employee
        {
            public int EmployeeID;
            public string EmployeeName;
            public double Salary;
        }
        static void Main(string[] args)
        {
            
        }
    }
}
