﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string dir;

            Console.WriteLine("Enter The directory name");
            dir = Console.ReadLine();
            DirectoryInfo d = new DirectoryInfo(dir);
            if (d.Exists)
            {
                Console.WriteLine("Directory Name is : " + d.Name);
                Console.WriteLine("Directory CreationTime is : " + d.CreationTime);
                Console.WriteLine("Directory LastAccessTime is : " + d.LastAccessTime);
                Console.WriteLine("Directory Root is : " + d.Root);
                Console.WriteLine("Directory LastWriteTime is : " + d.LastWriteTime);
                Console.WriteLine("Files Are : ");

                FileInfo[] files = d.GetFiles();
                foreach (FileInfo f in files)
                {
                    Console.WriteLine("\t" + f.Name);
                }
            }
            else
            {
                Console.WriteLine("Directory does not exists");
            }

            Console.ReadKey();
        }
    }
}
