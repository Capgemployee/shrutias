﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Capgemini";
            Console.WriteLine("UpperCase : " + str.ToUpper());

            Object o=str;
           // o.ToUpper(); Error 

            dynamic d = str;
           // string result = d.GetUpper(); Exception 
            string result = d.ToUpper();
            Console.WriteLine(result);

            Console.ReadKey();

        }
    }
}
