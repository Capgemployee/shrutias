﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApplication
{
    public class Employee
    {
        int empid;
        string name;
        double sal;

        public int EmpId
        {
            get { return empid; }
            set { empid = value; }
        }
        public string EmpName
        {
            get { return name; }
            set { name = value; }
        }
        public double EmpSal
        {
            get { return sal; }
            set { sal = value; }
        }
    }


}
