﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[5];
            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter Employee Id: ");
                emp[i].EmpId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Employee Name: ");
                emp[i].EmpName = (Console.ReadLine());

                Console.WriteLine("Enter Employee Salary: ");
                emp[i].EmpSal = Convert.ToDouble(Console.ReadLine());
 
            }
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("\n\nEmployee Id is : " + emp[i].EmpId);
                Console.WriteLine("\n\nEmployee Name is : " + emp[i].EmpName);
                Console.WriteLine("\n\nEmployee Salary is : " + emp[i].EmpSal);
            }
            Console.ReadKey();

        }
    }
}
