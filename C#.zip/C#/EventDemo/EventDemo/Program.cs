﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
   public delegate void EventHandlerDelegate(string msg);

   public class EventPublisher
   {
       public event EventHandlerDelegate MyClickEvent;

       public void InvokeClickEvent(string msg)
       {
           if (MyClickEvent != null)
           {
               MyClickEvent(msg);
           }
           else
           {
               Console.WriteLine("No Event Handler Available!");
           }
       }

   }

   public class Subscriber
   {
       public void HadlerMethod(string msg)
       {
           Console.WriteLine(msg);
           Console.WriteLine("Event is Handled");
       }
   }
    class Program
    {
        static void Main(string[] args)
        {
            EventPublisher pub = new EventPublisher();
            Subscriber sub = new Subscriber();
            pub.MyClickEvent += sub.HadlerMethod;
            pub.InvokeClickEvent("Hello!!!");

            Console.ReadKey();
        }
    }
}
