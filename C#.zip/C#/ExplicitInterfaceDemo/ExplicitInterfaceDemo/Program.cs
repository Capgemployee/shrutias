﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            IMyInterface m1 = new Employee();
            m1.Display();
            m1.Show();

            IMyInterface2 m2 = new Employee();
            m2.Print();
            m2.Show();

            Console.ReadKey();
        }
    }
}
