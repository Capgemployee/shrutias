﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo file=new FileInfo(@"D:\C#\FileInfo.txt");
                if(file.Exists)
                {
                    Console.WriteLine("File Name is : "+file.Name);
                    Console.WriteLine("File CreationTime is : " + file.CreationTime);
                    Console.WriteLine("File DirectoryName is : " + file.DirectoryName);
                    Console.WriteLine("File Extension is : " + file.Extension);
                    Console.WriteLine("File FullName is : " + file.FullName);
                    Console.WriteLine("File IsReadOnly is : " + file.IsReadOnly);
                    Console.WriteLine("File LastAccessTime is : " + file.LastAccessTime);
                    Console.WriteLine("File LastWriteTime is : " + file.LastWriteTime);
                    Console.WriteLine("File Length is : " + file.Length);
                   
                }
                else
                {
                    Console.WriteLine("File does not exists");
                }
            Console.ReadKey();

        }
    }
}
