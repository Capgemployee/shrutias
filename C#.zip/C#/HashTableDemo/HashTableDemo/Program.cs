﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace HashTableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hs = new Hashtable();
            hs.Add(1, ".NET");
            hs.Add(2, "JAVA");
            hs.Add(3, "TESTING");
            hs.Add(4, "ORACLE");
            hs.Add(5, "JAVA");
            hs.Add(6, "BI");

            Console.WriteLine("Hash table Data : ");
            Console.WriteLine(hs.ContainsKey(2));
            foreach (var key in hs.Keys)
            {
                Console.WriteLine("key : " + key + "Value : " + hs[key].ToString());
            }
            Console.ReadKey();
        }
    }
}
