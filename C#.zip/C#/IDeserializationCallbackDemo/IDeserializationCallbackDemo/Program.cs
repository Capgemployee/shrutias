﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


namespace IDeserializationCallbackDemo
{
     [Serializable]
    public class Student:IDeserializationCallback
    {
        int studID;
        string studName;
        int mark1;
        int mark2;
        int mark3;
        [NonSerialized]
        int total;
        double percentage;


        public Student(int studID, string studName, int mark1, int mark2, int mark3)
        {
            this.studID = studID;
            this.studName = studName;
            this.mark1 = mark1;
            this.mark2 = mark2;
            this.mark3 = mark3;
            this.total = mark1 + mark2 + mark3;
            this.percentage = total * 100/300;
        }

         
        public int StudentID
        {
            get { return studID; }
            set { studID = value; }
        }

        public string StudentName
        {
            get { return studName; }
            set { studName = value; }
        }

        public int Marks1
        {
            get { return mark1; }
            set { mark1 = value; }
        }

        public int Marks2
        {
            get { return mark2; }
            set { mark2 = value; }
        }

        public int Marks3
        {
            get { return mark3; }
            set { mark3 = value; }
        }

        public int Total
        {
            get { return total; }
        }

        public double Percentage
        {
            get { return percentage; }
        }

        public void CalcTotal()   //should be called before printing the entire data
        {
            total = mark1 + mark2 + mark3;
        }



        public void OnDeserialization(object sender)
        {
            CalcTotal();
        }
    }
    class Program
    {
      
        static void Main(string[] args)
        {

            Student s = new Student(101, "shruti", 76, 24, 67);
            FileStream fs = new FileStream("desrial.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter b = new BinaryFormatter();
            
            b.Serialize(fs, s);
            Console.WriteLine("Serialization Completed");

            fs.Close();

            fs = new FileStream("desrial.txt", FileMode.Open, FileAccess.Read);
            Student stud = (Student)b.Deserialize(fs);
            Console.WriteLine("Desrialization Completed");

            fs.Close();

            Console.WriteLine("Student ID : " + stud.StudentID);
            Console.WriteLine("Student Name : " + stud.StudentName);
            Console.WriteLine("Marks 1 : " + stud.Marks1);
            Console.WriteLine("Marks 2 : " + stud.Marks2);
            Console.WriteLine("Marks 3 : " + stud.Marks3);
            Console.WriteLine("Total : " + stud.Total);
            Console.WriteLine("Percentage : " + stud.Percentage);


            Console.ReadKey();

        }
    }
}
