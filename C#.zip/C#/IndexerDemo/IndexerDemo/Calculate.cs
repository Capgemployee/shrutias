﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    public class Calculate
    {
        int[] arr;
        public Calculate(int size)
        {
            arr = new int[size];
        }
        //int[,] matrix;
        //public Calculate(int dim1,int dim2)
        //{
        //    matrix = new int[dim1, dim2];
        //}
     
   
        public int this[int index]
        {
            get { return arr[index]; }
            set { arr[index] = value; }
        }

        //public int this[int i,int j]
        //{
        //    get { return matrix[i,j]; }
        //    set { matrix[i,j] = value; }
        //}


    }
}
