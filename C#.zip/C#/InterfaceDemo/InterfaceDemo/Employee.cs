﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    public class Employee : IPrintable
    {

        public void Print()
        {
            Console.WriteLine("Print method of employee class");
        }

        public void Display()
        {
            Console.WriteLine("Display method of employee class");
        }
    }
}
