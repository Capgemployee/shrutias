﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.Print();
            emp.Display();

            IPrintable p = new Employee();     //reference created
            p.Print();
            Console.ReadKey();
        }
    }
}
