﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorDemo
{
    public class DaysofTheWeek:IEnumerable
    {
        string[] days = { "Sun", "Mon", "Tues", "Wed", "Thur", "Fri", "Sat" };
    
    IEnumerator IEnumerable.GetEnumerator()
    {
        for (int i = 0; i < days.Length; i++)
        {
            yield return days[i];
        }
    }
    }
    
}
