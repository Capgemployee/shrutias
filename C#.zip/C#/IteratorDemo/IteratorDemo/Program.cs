﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorDemo
{
    //public class DaysofTheWeek
    //{
    //    string[] day={ "Sun", "Mon", "Tues", "Wed", "Thur", "Fri", "Sat" };
    //    public IEnumerable DisplayDays()
    //    {
    //        for (int i = 0; i < day.Length; i++)
    //        {
    //            yield return day[i];
    //        }
    //    }
    //}
    class Program
    {
        static void Main(string[] args)
        {
            DaysofTheWeek week = new DaysofTheWeek();
            Console.WriteLine("Days of the week are : ");
            foreach (string day in week)
            {
                Console.WriteLine(day);
            }

            //foreach (string item in week.DisplayDays())
            //{
            //    Console.WriteLine(day);
            //}
            Console.ReadKey();
        }
    }
}
