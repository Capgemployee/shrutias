﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionWithPara
{
    public delegate void MathDelegate(int num,int pow);

    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate annonymous = delegate(int num, int pow)
            {
                Console.WriteLine("Using Annonymous Method \n{0} ^ {1}=> {2}", num, pow, Math.Pow(num, pow));
            };
            annonymous(2, 3);

            MathDelegate lambda = (num, pow) => Console.WriteLine("Using Lambda Method \n{0} ^ {1}=> {2}", num, pow, Math.Pow(num, pow));

            lambda(2, 4);

            Console.ReadKey();
        }

    }
}
