﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;
namespace LibraryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            int sum, prod;

            Console.Write("Enter Number 1: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number 2: ");
            num2 = Convert.ToInt32(Console.ReadLine());

            sum = AddClass.Add(num1, num2);

            Console.WriteLine("Addition of {0} and {1} is,{2}", num1, num2, sum);

            Console.ReadKey();
        }
    }
}
