﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type calc = refAssembly.GetType("ReflectionLibrary.Calculate");

            MethodInfo[] calMethods = calc.GetMethods();

            for (int i = 0; i < calMethods.Length; i++)
            {
                Console.WriteLine("****** : " + calMethods[i].Name);
            }

            MethodInfo calMethod = calc.GetMethod("Add");  //non static method

            if (calMethod != null)
            {
                Object obj = refAssembly.CreateInstance("ReflectionLibrary.Calculate");
                int result = (int)calMethod.Invoke(obj, new Object[] { 20, 30 });
                Console.WriteLine("Result : " + result);
            }
            Console.WriteLine("Return Type :" + calMethod.ReturnType);

            MethodInfo subtract = calc.GetMethod("Subtract");
            if (subtract != null)
            {
                Object obj1 = refAssembly.CreateInstance("ReflectionLibrary.Calculate");
                int sub = (int)subtract.Invoke(null, new Object[] { 30, 20 });
                Console.WriteLine("Subtraction : " + sub);
            }


            

            Console.ReadKey();
        }

    }
}
