﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;

namespace MathConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperaqtions obj=new ArithmeticOperaqtions();
            int ch,num1;
           double num2,add,sub,multi,div,mod;

            Console.WriteLine("-----------------------------Calculator---------------------------------\n");
            Console.WriteLine("Enter First Number\n");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Second Number\n");
            num2 = Convert.ToInt32(Console.ReadLine());
            
           
            do
            {
                Console.WriteLine("\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Modulus\n");
                Console.WriteLine("Enter Your Choice\n");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        add = obj.Addition(num1, num2);
                        Console.WriteLine("Addtion of Number1 and Number2: " + add);
                        break;

                    case 2:
                        sub = obj.Subtraction(num1, num2);
                        Console.WriteLine("Subtraction of Number1 and Number2: " + sub);
                        break;
                    case 3:
                        multi = obj.Multiply(num1, num2);

                        Console.WriteLine("Multiplication of Number1 and Number2: " + multi);
                        break;

                    case 4:
                        div = obj.Divide(num1, num2);

                        Console.WriteLine("Division of Number1 and Number2: " + div);
                        break;

                    case 5:
                        mod = obj.Modulus(num1, num2);


                        Console.WriteLine("Modulus of Number1 and Number2: " + mod);
                        break;

                    default:
                        break;
                }
            } while (ch != 6);

        
            Console.ReadKey();
            

            
        }
    }
}
