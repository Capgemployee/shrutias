﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImprovedArithmeticDelegate
{
    public delegate void ArithmeticDelegate(int num1, int num2);
    
    
    public class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperation obj = new ArithmeticOperation();


            Console.WriteLine("Enter num1 :");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num2 :");
            int num2 = Convert.ToInt32(Console.ReadLine());


            char ch;
            do
            {
                Console.WriteLine("Enter Your Choice");
                Console.WriteLine("\n+: Add \n-: Subtract \n*:Multiply\n/:Divide\nM:Max Number");
                char choice = Convert.ToChar(Console.ReadLine());
                switch (choice)
                {
                    case '+': ArithmeticDelegate del = new ArithmeticDelegate(obj.Add);
                        obj.PerformArithmeticOperation(num1, num2, del);
                        break;
                    case '-': ArithmeticDelegate del1 = new ArithmeticDelegate(obj.Subtract);
                        obj.PerformArithmeticOperation(num1, num2, del1);
                        break;
                    case '*': ArithmeticDelegate del2 = new ArithmeticDelegate(obj.Multiply);
                        obj.PerformArithmeticOperation(num1, num2, del2);
                        break;
                    case '/': ArithmeticDelegate del3 = new ArithmeticDelegate(obj.Divide);
                        obj.PerformArithmeticOperation(num1, num2, del3);
                        break;
                    case 'M': ArithmeticDelegate del4 = new ArithmeticDelegate(obj.Max);

                        obj.PerformArithmeticOperation(num1, num2, del4);
                        break;
                    default: Console.WriteLine("Please enter a valid operation");
                        break;
                }
                Console.WriteLine("Do you want to continue (y/Y)");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y' || ch == 'Y');
            Console.ReadKey();
        }
    }
}

