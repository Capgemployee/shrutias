﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement
{
   public class Car
    {
       string[] Name=new string[2];
       string[] Model = new string[2];
       int[] Year = new int[2];
       double[] Price = new double[2];
       public Car()
       {
           for (int i = 0; i < 1; i++)
           {
               Console.WriteLine("\nEnter a Car's Make Name:");


               Name[i] = Console.ReadLine();


               Console.WriteLine("\nEnter the Model:");


               Model[i] = Console.ReadLine();


               Console.WriteLine("\nEnter the Year of Launching:");


               Year[i] = Convert.ToInt32(Console.ReadLine());


               Console.WriteLine("\nEnter the Sales Price:");

               Price[i] = Convert.ToInt32(Console.ReadLine());
           }
       }

   //    public Car(string Name[2])
   //    {
   //     for (int i = 0; i < 2; i++)
   //{
   //        this.Name[i] = Name[i];
   //        Console.WriteLine(" New Car Name:" + Name[i]);
   //}
   //    }

       public void Disp()
       {
           Console.WriteLine("\n-----------------------------Car Details-------------------------------------\n");
           Console.WriteLine("\tCar's_Make_Name\t\tModel\tYear of Launching\tPrice\n");
           for (int i = 0; i < 1; i++)
           {
               Console.WriteLine("\t\t"+Name[i] + "\t\t" + Model[i] + "\t\t" + Year[i] + "\t\t" + Price[i]+"\n");
           }
           Console.WriteLine("\n-----------------------------------------------------------------------------\n");
       }

   



       }


    }

