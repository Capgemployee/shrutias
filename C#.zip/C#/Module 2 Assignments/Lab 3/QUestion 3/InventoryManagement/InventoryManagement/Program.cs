﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement
{
    class Program
    {
        static void Main(string[] args)
        {


            
            int ch;
            do
            {
                Console.WriteLine("1:Add New Car Details\n2:Modify the details of Car\n3:Search for Particular Car Deatils\n4:List  all the car details in Catalog\n5:Delete a car detail from catalog\n6:Exit\n");
                Console.WriteLine("\nEnter Your Choice:");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Car obj1 = new Car();
                        break;
                    //case 2:
                    //    Car obj2 = new Car("Maruti");
                    //    break;
                    case 2:
                        Car obj2 = new Car();
                        obj2.Disp();
                        break;
                    default: break;
                }
            } while (ch != 4);
                     
        }
    }
}
