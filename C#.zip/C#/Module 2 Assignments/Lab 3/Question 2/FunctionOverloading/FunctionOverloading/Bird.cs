﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionOverloading
{
    public class Bird
    {
        public string Name;
        public double Maxheight;

       

        public Bird() //Default Constructor
        {
            Name = "Mountain Eagle";
            Maxheight = 500;
            
            Console.WriteLine(Name + " is flying at height " + Maxheight);
        }
        public Bird(string birdname, double max_ht) //Overloaded Constructor
        {
            Console.WriteLine(birdname + " is flying at " + max_ht);
        }
        public void fly()
        {
            Console.WriteLine(Name+" is flying at altitude " + Maxheight);
        }
        public void fly(double AtHeight)
        {
            if (AtHeight <= this.Maxheight)
            {
                Console.WriteLine(Name + " flying at " + AtHeight);
            }
            else
            {
                Console.WriteLine(Name+"cannot fly at height "+AtHeight);
            }
        }
    }
}
