﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetailsConsole
{
    public class ContractEmployee : Employee
    {
      public  double Perks = 1200;

      public double EmpPerks
      {
          get { return Perks; }
          set { Perks = value; }
      }


        public override void GetSalary()
        {
          
            Console.WriteLine("Enter Emlpoyee Salary\n");
            Salary = Convert.ToInt32(Console.ReadLine());
            Salary = Salary + Perks;
            Console.WriteLine("NewSalary:"+Salary);
          
        }
    }
}
