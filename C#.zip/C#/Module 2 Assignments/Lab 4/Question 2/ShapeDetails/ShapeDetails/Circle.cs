﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDetails
{
    public class Circle:Shape
    {
        public override void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
}
