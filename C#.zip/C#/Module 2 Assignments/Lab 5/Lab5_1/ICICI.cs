﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_1
{
    class ICICI : BankAccount
    {

        public override bool Withdraw(double amount)
        {
            if (balance - amount >= 0)
            {
                Console.WriteLine("withdrawl Possible");
                balance = balance - amount;
                return true;
            }
            else
            {
                Console.WriteLine("withdrawl not Possible");
                return false;
            }
        }
        public override bool Transfer(IBankAccount toAccount, double amount)
        {
           
            if (balance - amount >= 1000)
            {
                Console.WriteLine("Transfer Possible");
                balance = balance - amount;
                return true;
            }
            else
            {
                Console.WriteLine("Transfer not Possible");
                return false;
            }
        }

        public override double GetBalance()
        {
            return balance;
        }




        public override ClassLibrary.BankAccount.BankAccountTypeEnum AccountType
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }
    }
    
}
