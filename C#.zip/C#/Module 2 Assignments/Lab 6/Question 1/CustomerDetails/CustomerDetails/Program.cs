﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerDetails
{
  
   public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Customer ID :");
                int id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Customer Name :");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Address  :");
                string add = Console.ReadLine();
                Console.WriteLine("Enter City :");
                string city = Console.ReadLine();
                Console.WriteLine("Enter Phone no :");
                long phone = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter Credit Limit :");
                double cl = Convert.ToDouble(Console.ReadLine());
                if (cl > 50000)
                {
                    throw new InvalidCreditLimitException("Pls enter credit limit below 50000");
                }
            }
            catch (InvalidCreditLimitException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}

