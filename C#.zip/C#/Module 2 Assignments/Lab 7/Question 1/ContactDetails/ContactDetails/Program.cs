﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactDetails
{
    public class contact
    {
        public int ContactNo { get; set; }
        public String ContactName { get; set; }
        public string cellNo { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<contact> list = new List<contact>();
            list.Add(new contact() { ContactNo = 898107046, ContactName = "Vikas", cellNo = "MGF34" });
            list.Add(new contact() { ContactNo = 898107046, ContactName = "Vinay", cellNo = "MGF34" });
            list.Add(new contact() { ContactNo = 887458852, ContactName = "Prasad", cellNo = "SD65D" });
            list.Add(new contact() { ContactNo = 889816836, ContactName = "Robert", cellNo = "GFD756" });


            Console.WriteLine("\nContains: ContactNo=654588453: " + list.Contains(new contact() { ContactNo = 654588453, ContactName = "", cellNo = "" }));

            foreach (var cont in list)
            {
                if (cont.ContactNo == 889816836)
                {
                    cont.ContactName = "Mohit";
                }

            }


            foreach (var ele in list)
            {
                Console.WriteLine(" ContactNO :" + ele.ContactNo + " CtactName :" + ele.ContactName + " CellNo : " + ele.cellNo);
            }

        }
    }
}
