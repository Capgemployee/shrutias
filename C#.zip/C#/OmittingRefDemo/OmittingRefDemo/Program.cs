﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;

namespace OmittingRefDemo
{
    class Program
    {
        static void Main(string[] args)
        {
           var application = new Microsoft.Office.Interop.Word.Application();

            string fileName=@"D:\C#\RefDemo";
            application.Documents.Open(FileName: fileName,ReadOnly:true);

        }
    }
}
