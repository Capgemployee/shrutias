﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutParamtereDemo
{
    class Program
    {
        public void CircleFunc(int radius, out double area, out double  volumn)
        {
            area = 3.14 * radius * radius;
            volumn = 4 / 3 * 3.14 * radius * radius * radius;
        }

         static void Main(string[] args)
        {

            int radius;
            double area, vloumn;

            Console.WriteLine("Enter Radius: ");
            radius = Convert.ToInt32(Console.ReadLine());

             Program p=new Program();
             p.CircleFunc(radius, out area, out vloumn);

             Console.WriteLine("Area of Circle = " + area);
             Console.WriteLine("Volumn of Circle = " + vloumn);
             Console.ReadKey();
      
        }
    }
}
