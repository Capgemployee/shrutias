﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverloadingDemo
{
    class Program
    {
        public void Add(int num1, int num2)
        {
            Console.WriteLine("{0}+{1}=>{2}",num1,num2,(num1+num2));
        }
        public void Add(int num1, int num2,int num3)
        {
            Console.WriteLine("{0}+{1}+{2}=>{3}", num1, num2, num3, (num1 + num2+ num3));
        }
        public void Add(double num1, double num2, double num3)
        {
            Console.WriteLine("{0}+{1}+{2}=>{3}", num1, num2, num3, (num1 + num2 + num3));
        }
        public void Add(int num1, float num2)
        {
            Console.WriteLine("{0}+{1}=>{2}", num1, num2, (num1 + num2));
        }
        public void Add(float num1, int num2)
        {
            Console.WriteLine("{0}+{1}=>{2}", num1, num2, (num1 + num2));
        }
        static void Main(string[] args)
        {
            //int firstNum;
            //int secondNum;

            //Console.WriteLine("Enter First number: ");
            //firstNum = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter Second number: ");
            //secondNum = Convert.ToInt32(Console.ReadLine());

            Program p = new Program();
            p.Add(2, 9);
            p.Add(2, 9, 6);
            p.Add(2.4, 9.7, 6.9);
            p.Add(2, 2.8f);
            p.Add(3.6f, 7);
            Console.ReadKey();
        }
    }
}
