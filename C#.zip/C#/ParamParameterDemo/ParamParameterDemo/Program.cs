﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParamParameterDemo
{
    class Program
    {
        public string Concat(params string[] str)
        {
            string result = "";
            for (int i = 0; i < str.Length; i++)
            {
                result = result + str[i];
            }
            return result;
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            Console.WriteLine("String after concat method");
            Console.WriteLine(p.Concat("shruti"," ", "jamgade"));
            Console.ReadKey();
        }
    }
}
