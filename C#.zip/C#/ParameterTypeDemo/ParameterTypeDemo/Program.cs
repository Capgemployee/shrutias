﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterTypeDemo
{
    class Program
    {

        public void Swap(int n1, int n2)
        {
            int temp;
            temp = n1;
            n1 = n2;
            n2 = temp;
            Console.WriteLine(" ");
            Console.WriteLine("Value in mathod pass by value= " + n1);
            Console.WriteLine("Value in mathod pass by value= " + n2);

        }

        public void SwapByRef(ref int n1, ref int n2)
        {
            int temp;
            temp = n1;
            n1 = n2;
            n2 = temp;
            Console.WriteLine(" ");
            Console.WriteLine("Value in mathod pass by ref= " + n1);
            Console.WriteLine("Value in method pass by ref= " + n2);

        }

        static void Main(string[] args)
        {
            int num1;
            int num2;
            Console.WriteLine("Enter first number");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter second number");
            num2 = Convert.ToInt32(Console.ReadLine());

            Program p=new Program();
            p.Swap(num1,num2);
            Console.WriteLine(" " );
            Console.WriteLine("First number after swapping= " + num1);
            Console.WriteLine("Second number after swapping= " + num2);

            p.SwapByRef(ref num1, ref num2);
            Console.WriteLine(" ");
            Console.WriteLine("First number after swapping= " + num1);
            Console.WriteLine("Second number after swapping= " + num2);

            Console.ReadKey();
        }
    }
}
