﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    public class Employee
    {
        int empID;
        //read only
        public int EmployeeID
        {
            get { return empID; }
        }
        string name;
        //read-write Property
        public string EmployeeName
        {
            get { return name; }
            set { name = value; }

        }
        //write only
        DateTime dob;
        public DateTime DOB
        {
            set { dob = value; }
        }
        public Employee(int id)
        {
            this.empID = id;
        }

        static void Main(string[] args)
        {
            Employee emp = new Employee(101);

            emp.EmployeeName = "Shruti";
            emp.DOB = Convert.ToDateTime("02/02/1994");

            Console.WriteLine("Employee ID: " + emp.EmployeeID);
            Console.WriteLine("Employee Name: " + emp.EmployeeName);
            //Console.WriteLine("Employee date of birth: "+emp.DOB); error write  only 
            Console.ReadKey();
        }
        
    }
}
