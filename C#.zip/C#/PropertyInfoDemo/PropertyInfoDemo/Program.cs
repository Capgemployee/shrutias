﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PropertyInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type calc = refAssembly.GetType("ReflectionLibrary.Calculate");

            PropertyInfo[] empProp = calc.GetProperties();

            foreach (PropertyInfo p in empProp)
            {
                Console.WriteLine("property name : " + p.Name);
                Console.WriteLine();
            }
            Object obj = refAssembly.CreateInstance("ReflectionLibrary.Employee");

            PropertyInfo id = calc.GetProperty("EmployeeID");
            if (id != null)
            {
                id.SetValue(obj, 101);
                Console.WriteLine("Employee ID : " + id.GetValue(obj));
            }

                Console.ReadKey();


        }
    }
}
