﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace QueueDemo
{
    class Test
    {
        static void Main(string[] args)
        {
            Queue queueObject = new Queue();
            queueObject.Enqueue("shruti");
            queueObject.Enqueue("Mani");
            queueObject.Enqueue("Aayu");
            while (queueObject.Count > 0)
            {
                Console.WriteLine(queueObject.Dequeue());
            }
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
