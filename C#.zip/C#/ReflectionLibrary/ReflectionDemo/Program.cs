﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionDemo
{
    class Program
    {

        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type[] refTypes = refAssembly.GetTypes();
            //foreach (Type t in refTypes)
            //{
            //    Console.WriteLine(t);
                
            //}
            for (int i = 0; i < refTypes.Length; i++)
            {
                Console.WriteLine("Nameof the type : " + refTypes[i].Attributes);
                Console.WriteLine("Nameof the type : " + refTypes[i].BaseType);
                Console.WriteLine("Nameof the type : " + refTypes[i].CustomAttributes);
                Console.WriteLine("Nameof the type : " + refTypes[i].IsNested);
                Console.WriteLine("Nameof the type : " + refTypes[i].ContainsGenericParameters);
                Console.WriteLine("Nameof the type : " + refTypes[i].Assembly);
                Console.WriteLine("Nameof the type : " + refTypes[i].AssemblyQualifiedName);
                Console.WriteLine("Nameof the type : " + refTypes[i].FullName);
                Console.WriteLine("Nameof the type : " + refTypes[i].GenericTypeArguments);
                Console.WriteLine("Nameof the type : " + refTypes[i].IsAbstract);
                Console.WriteLine("Nameof the type : " + refTypes[i].IsArray);
                Console.WriteLine("Nameof the type : " + refTypes[i].IsClass);
                Console.WriteLine("Nameof the type : " + refTypes[i].IsInterface);

                Console.ReadKey();
 
            }
        }
    }
}
