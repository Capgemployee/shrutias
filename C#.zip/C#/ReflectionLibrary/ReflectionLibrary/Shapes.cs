﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public abstract class Shapes
    {
        public abstract void CalcArea();

    }

    sealed class Circle : Shapes
    {
        public override void CalcArea()
        {
            Console.WriteLine("Method called");
        }
    }
}
