﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClassDemo
{
    public sealed class Employee
    {
        public void Display()
        {
            Console.WriteLine("Display Method of Employee Class");
        }
    }
}
