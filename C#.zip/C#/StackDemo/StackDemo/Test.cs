﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace StackDemo
{
    public class Test
    {
        static void Main(string[] args)
        {
            Stack stackObject = new Stack();
            stackObject.Push("Shruti");
            stackObject.Push("Mani");
            stackObject.Push("Aayu");
            while (stackObject.Count > 0)
            {
            Console.WriteLine(stackObject.Pop());        
            }
            Console.ReadLine();
            Console.ReadKey();

        }
    }
}
