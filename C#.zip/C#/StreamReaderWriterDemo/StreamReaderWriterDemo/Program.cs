﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StreamReaderWriterDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream file = new FileStream("stream.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(file);
            sw.WriteLine(2355);
            sw.WriteLine("Shruti");
            sw.WriteLine(true);
            sw.Flush();
            
            file.Close();

            FileStream fRead = new FileStream("stream.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fRead);

            string data = sr.ReadToEnd();
            Console.WriteLine(data);
            //Console.WriteLine(sr.ReadToEnd());
  
            fRead.Close();

            
            Console.ReadKey();

        }
    }
}
