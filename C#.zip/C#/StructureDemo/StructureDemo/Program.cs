﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    class Program
    {
        public struct Point
        {
            int x, y;
            public Point(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
            public int X
            {
                get { return x; }
                set { x = value; }
            }
            public int Y
            {
                get { return y; }
                set { y = value; }
            }
        }
        static void Main(string[] args)
        {
            Point pt = new Point(2, 5);
            pt.X += 100;
            pt.Y += 50;
            int px = pt.X;
            int py = pt.Y;
            Console.WriteLine("The value of px= {0} and py={1}",px,py);
            Console.ReadKey();
        }
    }
}
