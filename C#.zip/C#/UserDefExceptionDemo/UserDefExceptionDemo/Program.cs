﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefExceptionDemo
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string Employeename { get; set; }
        public double Salary { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            try
            {
                Console.Write("Enter Employee ID: ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
                if (emp.EmployeeID > 100000 || emp.EmployeeID < 999999)
                {
                    throw new EmployeeException();
                }
            }

            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();

        }
    }
}
