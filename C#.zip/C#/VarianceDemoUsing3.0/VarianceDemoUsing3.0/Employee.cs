﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VarianceDemoUsing3._0
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        
        public Employee(int empID, string name)
        {
            EmpID = empID;
            EmpName = name;
           
        }

    }
}
