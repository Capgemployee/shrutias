﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VarianceDemoUsing3._0
{
    public class Manager:Employee

    {
        public int Allowance { get; set; }
        public Manager(int empID, string name, int all)
            : base(empID, name)
        {
            EmpID = empID;
            EmpName = name;
            Allowance = all;
        }
    }
}
