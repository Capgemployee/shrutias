﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VarianceDemoUsing3._0
{
    class Program
    {

        
        static void Main(string[] args)
        {
            IList<Manager> mgr = new List<Manager>();
            mgr.Add(new Manager(101,"Shruti",2000));
            mgr.Add(new Manager(102,"Shru",3000));
            mgr.Add(new Manager(103,"Mani",6000));
            mgr.Add(new Manager(104,"Aayu",6000));

            Employee e=new Manager(1,"abc",2344);

            IEnumerable<Employee> emp = mgr;

            foreach (Manager m in emp)
            {
                Console.WriteLine("Employee ID : " + m.EmpID + "Employee Name : " + m.EmpName + "Aloowance : " + m.Allowance);
            }



        }
    }
}
