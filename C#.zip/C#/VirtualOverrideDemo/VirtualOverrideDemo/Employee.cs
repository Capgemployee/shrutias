﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideDemo
{
    public class Employee
    {
        public virtual void Show()
        {
            Console.WriteLine("show method of employee");
        }
    }
}
