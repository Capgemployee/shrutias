namespace UtilityMethods
{
	public class MulClass
	{
		public static int Mul(int num1, int num2)
		{
			return (num1*num2);
		}
	}
}